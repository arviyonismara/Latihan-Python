from abq_data_entry.application import Application
import os

print(os.getcwd())

app = Application()
app.mainloop()
