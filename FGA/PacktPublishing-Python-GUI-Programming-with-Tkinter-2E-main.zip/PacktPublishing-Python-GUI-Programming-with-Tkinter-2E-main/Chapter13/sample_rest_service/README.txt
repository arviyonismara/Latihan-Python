This sample REST service script requires the Flask library, which can be installed using pip:

$ pip install --user flask

To run it, execute this in a terminal:

$ python sample_rest_service.py

Note that it will only be available on the local system; you cannot connect to it from another host. 
