from abq_data_entry.application import Application

def main():
  app = Application()
  app.mainloop()

if __name__ == '__main__':
    main()
