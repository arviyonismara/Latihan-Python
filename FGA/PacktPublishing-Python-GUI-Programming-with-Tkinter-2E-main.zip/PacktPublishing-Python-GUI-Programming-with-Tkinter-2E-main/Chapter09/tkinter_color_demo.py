import tkinter as tk

l = tk.Label(text='Hot Dog!', fg='yellow', bg='red')
l.pack(expand=1, fill='both')

l2 = tk.Label(text='Also Hot Dog!', foreground='#FFFF00', background='#FF0000')
l2.pack(expand=1, fill='both')
